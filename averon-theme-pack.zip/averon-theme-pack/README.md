# Averon Theme Pack (for a PojavLauncher fork)

## Steps
1. Fork PojavLauncher on GitHub.
2. Copy `res/` files into `app/src/main/res/` of your fork.
3. Copy `java/.../averon/` into `app/src/main/java/net/kdt/pojavlaunch/averon/`.
4. In `AndroidManifest.xml` set `android:theme="@style/Theme.Averon"` on <application>
   and `android:label="Averon"`.
5. Use `@drawable/averon_bg_card` as background for cards/panels.
6. Open `AveronAdvancedFragment` from your settings screen.
7. Pass `AveronPrefs.ramMb()`, `renderer()`, `javaVersion()`, `jvmArgs()` into the launch code.
8. Push, then GitHub > Actions > build > download APK.

## Notes
- Keep GPL-3.0 license and credit PojavLauncher. Source must stay public.
- If the build errors, copy the error and send it to Claude.
