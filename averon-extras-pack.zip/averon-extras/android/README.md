# Averon Android extras
- res/drawable/averon_ic_foreground.xml + res/mipmap-anydpi-v26/averon_ic_launcher.xml -> app icon
  Manifest: android:icon="@mipmap/averon_ic_launcher"
- res/layout/averon_activity_home.xml -> home screen
- java/.../averon/AveronApi.java        -> talks to admin backend (set BASE_URL)
- java/.../averon/AveronHomeActivity.java -> register in AndroidManifest, make it the launcher activity
  (or keep Pojav's own home and just reuse the layout/theme)
- Add <uses-permission android:name="android.permission.INTERNET"/> if missing.
Remaining work: connect the TODO launch hook to Pojav's real launch code.
